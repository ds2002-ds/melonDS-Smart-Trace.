#pragma once
#include <cstdint>
#include <cstdio>
namespace melonDS::SmartTrace {
struct Record { uint32_t kind, frame, pc, op, r0, r1, r2, r3, lr, extra; };
static_assert(sizeof(Record)==40);
inline FILE* file=nullptr;
inline uint32_t frame=0, expected=0, pc=0, count=0;
inline constexpr uint32_t limit=1500000;
inline bool failed=false;
inline void stop(){ if(file){ if(std::fclose(file)!=0) failed=true; file=nullptr; } }
inline bool start(const char* path){ stop(); frame=expected=pc=count=0; failed=false; file=std::fopen(path,"wb"); if(!file)return false; std::setvbuf(file,nullptr,_IOFBF,65536); return true; }
inline void emit(const Record& r){ if(!file)return; if(std::fwrite(&r,sizeof(r),1,file)!=1){failed=true;stop();return;} if(++count>=limit)stop(); }
inline void instruction(uint32_t address,uint32_t op,const uint32_t* r,bool thumb){ if(!file)return; pc=address; bool jump=address!=expected; expected=address+(thumb?2:4); if(jump && address>=0x02000000 && address<0x022944e0) emit({1,frame,address,op,r[0],r[1],r[2],r[3],r[14],thumb?1u:0u}); }
inline void write(uint32_t address,uint32_t value,uint32_t width){ if(file && address>=0x022973f8 && address<0x02297400) emit({2,frame,pc,address,value,width,0,0,0,0}); }
inline void tick(uint32_t a,uint32_t b){ if(file){ ++frame; emit({3,frame,0,0,a,b,0,0,0,0}); if(file && frame%60==0 && std::fflush(file)!=0){failed=true;stop();} } }
}
