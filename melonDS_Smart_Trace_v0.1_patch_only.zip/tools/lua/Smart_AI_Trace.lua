-- Disable JIT in emulator settings before starting the duel.
if not smarttrace then error('Richiede melonDS Smart Trace modificato') end
if not smarttrace.start() then error('Impossibile creare il log') end
print('Registrazione attiva: gioca il turno CPU. Arresta lo script per terminare.')
for i=1,3600 do
    emu.frameadvance()
    local n,active,failed=smarttrace.tick()
    if i%60==0 then print('Frame '..i..' / record '..n) end
    if not active then print(failed and 'Errore scrittura' or 'Limite raggiunto'); break end
end
smarttrace.stop()
print('Log: '..emu.getdir()..'/smart_trace.bin')
