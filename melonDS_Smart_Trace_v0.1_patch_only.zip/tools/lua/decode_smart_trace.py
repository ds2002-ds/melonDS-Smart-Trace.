import struct, sys, csv
with open(sys.argv[1], 'rb') as f:
    w=csv.writer(sys.stdout)
    w.writerow(['kind','frame','pc','op_or_address','r0_or_value','r1_or_width','r2','r3','lr','extra'])
    while b:=f.read(40):
        if len(b)!=40: raise ValueError('Truncated record')
        k,fr,*v=struct.unpack('<10I',b)
        w.writerow([k,fr,*[f'0x{x:08x}' for x in v]])
